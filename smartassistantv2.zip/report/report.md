# Report Define Bot-script

## Usecase

Composing demand's user which KB/DB adaptable.

## Challenge

Wrong categories:
* Confuse "diagnosis" with "time_show_up"

Propose solutions:
* re-architect